Ordivon Runtime Introduction — 2026 historical explanatory edition
Open index.html in a browser after extracting this ZIP.
Videos and interactive HTML work locally. The optional WebVTT captions may
require an HTTP origin on browsers that disallow file:// caption tracks.
Use python3 -m http.server from the extracted folder if necessary.
All content is source-revision bound; it is not a current feature inventory.
No claim of YouTube/Douyin/Upwork publication or audience response.
