Ordivon Runtime Introduction — 2026 historical explanatory edition
Open index.html in a browser after extracting this ZIP.
Videos, English captions, and interactive HTML open locally via file://.
The HTML carries the exact WebVTT data for offline Chromium and Firefox.
Separate caption files are retained for downloads and video editors.
The article opens as formatted HTML; its Markdown source remains in the ZIP.
All content is source-revision bound; it is not a current feature inventory.
No claim of YouTube/Douyin/Upwork publication or audience response.
